# Car Rental System (Java OOP Project)

## 📋 Description
This project is a **Car Rental System** developed in Java using Object-Oriented Programming (OOP) principles.

## 🚀 Features
- Classes: `Car`, `RentalAgency`
- Admin login (Username: admin / Password: pass123)
- Rent and return cars
- List available cars

## 🧪 How to Run (Online)
Use [JDoodle](https://www.jdoodle.com/online-java-compiler/) or [Replit](https://replit.com/)

## 💻 Run Locally
```bash
javac CarRentalSystem.java
java CarRentalSystem
```

## 🔗 GitHub
Upload all contents and screenshots to your GitHub repository.

Made for ZETECH Java OOP Coursework.
