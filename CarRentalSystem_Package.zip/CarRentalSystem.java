import java.util.*;

class Car {
    String model;
    String registration;
    boolean isRented;

    Car(String model, String registration) {
        this.model = model;
        this.registration = registration;
        this.isRented = false;
    }

    void rent() {
        isRented = true;
    }

    void returnCar() {
        isRented = false;
    }

    public String toString() {
        return model + " (" + registration + ") - " + (isRented ? "Rented" : "Available");
    }
}

class RentalAgency {
    List<Car> cars;

    RentalAgency() {
        cars = new ArrayList<>();
        cars.add(new Car("Toyota Corolla", "KDA 123A"));
        cars.add(new Car("Honda Civic", "KDB 456B"));
        cars.add(new Car("Nissan Xtrail", "KDC 789C"));
    }

    void showAvailableCars() {
        System.out.println("\nAvailable Cars:");
        for (Car car : cars) {
            if (!car.isRented) {
                System.out.println(car);
            }
        }
    }

    void rentCar(String registration) {
        for (Car car : cars) {
            if (car.registration.equalsIgnoreCase(registration) && !car.isRented) {
                car.rent();
                System.out.println("\nCar rented successfully: " + car);
                return;
            }
        }
        System.out.println("\nCar not available for rent.");
    }

    void returnCar(String registration) {
        for (Car car : cars) {
            if (car.registration.equalsIgnoreCase(registration) && car.isRented) {
                car.returnCar();
                System.out.println("\nCar returned successfully: " + car);
                return;
            }
        }
        System.out.println("\nCar not found or was not rented.");
    }
}

public class CarRentalSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RentalAgency agency = new RentalAgency();

        int attempts = 3;
        boolean loggedIn = false;

        while (attempts > 0) {
            System.out.print("Enter username: ");
            String username = scanner.nextLine();

            System.out.print("Enter password: ");
            String password = scanner.nextLine();

            if (username.equals("admin") && password.equals("pass123")) {
                loggedIn = true;
                break;
            } else {
                attempts--;
                System.out.println("Invalid credentials. Attempts remaining: " + attempts);
            }
        }

        if (!loggedIn) {
            System.out.println("Access denied.");
            return;
        }

        while (true) {
            System.out.println("\n=== Car Rental System Menu ===");
            System.out.println("1. View available cars");
            System.out.println("2. Rent a car");
            System.out.println("3. Return a car");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    agency.showAvailableCars();
                    break;
                case "2":
                    System.out.print("Enter car registration to rent: ");
                    String rentReg = scanner.nextLine();
                    agency.rentCar(rentReg);
                    break;
                case "3":
                    System.out.print("Enter car registration to return: ");
                    String returnReg = scanner.nextLine();
                    agency.returnCar(returnReg);
                    break;
                case "4":
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
